package com.nofrisdan.myuts18030046;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class MainDetail extends AppCompatActivity {

//    ======== variabel detail

    TextView nim,mhs,kelas;
    EditText txt_tgl, txt_jam,matkul,sks,sifatUjian,programStudi,pengampu;
    Button btn_get_datetime,submit,reset;

//    ===== Variabel date time picker
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);

//        Instansiasi Variabel TEXT VIEW
        nim = (TextView) findViewById(R.id.nim_mhs);
        mhs = (TextView) findViewById(R.id.nama_mhs);
        kelas = (TextView) findViewById(R.id.kelas_mhs);

//        Instansiasi Variabel EDIT TEXT
        txt_tgl = (EditText) findViewById(R.id.txt_tgl);
        txt_jam = (EditText) findViewById(R.id.txt_jam);
        matkul = (EditText) findViewById(R.id.matkul);
        sks = (EditText) findViewById(R.id.sks);
        sifatUjian = (EditText) findViewById(R.id.sifat_ujian);
        programStudi = (EditText) findViewById(R.id.program_studi);
        pengampu = (EditText) findViewById(R.id.dosen_pengampu);

//        Instansiasi BUTTON
        btn_get_datetime = (Button) findViewById(R.id.btn_get_datetime);
        submit = (Button) findViewById(R.id.btn_submit);
        reset = (Button) findViewById(R.id.btn_reset);







//        ========== GET INTENT DARI MAIN ACTIVITY ======

        if(getIntent().getStringExtra("nimMhs") != null){
            String nimMhs = getIntent().getStringExtra("nimMhs");
            nim.setText("NIM : "  + nimMhs);
        }
        if(getIntent().getStringExtra("namaMhs") != null){
            String namaMhs = getIntent().getStringExtra("namaMhs");
            mhs.setText("NAMA : "+namaMhs);
        }
        if(getIntent().getStringExtra("kelasMhs") != null){
            String kelasMhs = getIntent().getStringExtra("kelasMhs");
            kelas.setText("Kelas : "+kelasMhs);
        }

        //        DATE TIME PICKER

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR,year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                updateLabel();
            }
        };

//        ====== event JAm =====
     txt_jam.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Calendar timeNow = Calendar.getInstance();
             int hour = timeNow.get(Calendar.HOUR_OF_DAY);
             int minute = timeNow.get(Calendar.MINUTE);
             TimePickerDialog TimeSet;

             TimeSet = new TimePickerDialog(MainDetail.this, new TimePickerDialog.OnTimeSetListener() {
                 @Override
                 public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        txt_jam.setText(selectedHour + ":" + selectedMinute);
                 }
             },hour,minute,true);
             TimeSet.setTitle("Select Time");
             TimeSet.show();
         }
     });

//     event button
        btn_get_datetime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainDetail.this,"Tanggal :"+txt_tgl.getText().toString() + "\n"
                        +"Jam : " +txt_jam.getText().toString(),
                        Toast.LENGTH_LONG).show();
            }
        });

//     ====== EVENT TGL =====
        txt_tgl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainDetail.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });












//        SUBMIT
            submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String nimMhs = getIntent().getStringExtra("nimMhs");
                    String namaMhs = getIntent().getStringExtra("namaMhs");
                    String kelasMhs = getIntent().getStringExtra("kelasMhs");

                    String tglUjian = txt_tgl.getText().toString();
                    String jamUjian = txt_jam.getText().toString();
                    String mataKuliah = matkul.getText().toString();
                    String sKs = sks.getText().toString();
                    String sftUjian = sifatUjian.getText().toString();
                    String prodi = programStudi.getText().toString();
                    String dsn_pengampu = pengampu.getText().toString();



//                    kirim data ke output
                    Intent i = new Intent(MainDetail.this,MainOutput.class);

                    i.putExtra("namaMhs",namaMhs);
                    i.putExtra("nimMhs",nimMhs);
                    i.putExtra("kelasMhs",kelasMhs);

                    i.putExtra("tgl",tglUjian);
                    i.putExtra("jam",jamUjian);
                    i.putExtra("matkul",mataKuliah);
                    i.putExtra("sks",sKs);
                    i.putExtra("sifatUjian",sftUjian);
                    i.putExtra("prodi",prodi);
                    i.putExtra("dsnPengampu",dsn_pengampu);


                    startActivity(i);
                    finish();



                }
            });


//        Reset
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_tgl.setText("");
                txt_jam.setText("");
                matkul.setText("");
                sks.setText("");
                sifatUjian.setText("");
                programStudi.setText("");
                pengampu.setText("");
            }
        });

    }

    private void updateLabel(){

        String myFormat = "dd-MM-yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        txt_tgl.setText(sdf.format(myCalendar.getTime()));



    }


}