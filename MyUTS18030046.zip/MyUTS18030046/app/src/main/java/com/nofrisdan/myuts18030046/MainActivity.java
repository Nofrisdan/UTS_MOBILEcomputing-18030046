package com.nofrisdan.myuts18030046;



import android.content.Intent;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nama_et,nim_et;
    Button btn_et;

    RadioGroup radio_grp;
    RadioButton kls_A, kls_B,radioButton;

    // ===== function pertama yang secara default di jalankan atau yang ditampilkan pertama  kali
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

//        =======   View layout yang di tampilkan pertama kali yakni activity_main sama seperti
//          public function __construct() di php
//        ======

        setContentView(R.layout.activity_main);

//     Instansiasi Edit Text
        nama_et = (EditText) findViewById(R.id.nama_mahasiswa);
        nim_et = (EditText) findViewById(R.id.nim);

//        Instansiasi Button
        btn_et = (Button) findViewById(R.id.input_data);

//        INstansiasi Radio Button
        radio_grp = (RadioGroup) findViewById(R.id.radio_grp);
        kls_A = (RadioButton) findViewById(R.id.kelas_A);
        kls_B = (RadioButton) findViewById(R.id.Kelas_B);

        btn_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String namaMhs = nama_et.getText().toString();
                String nimMhs = nim_et.getText().toString();

                int radioId = radio_grp.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);

                String kelasMhs = radioButton.getText().toString();


                            try {


                                if (nama_et == null || nim_et == null) {

                            //                    ==== TAMPILKAN TOAST ERROR =====

                                    Toast.makeText(getApplicationContext(), "Seluruh Input tidak boleh Kosong !!", Toast.LENGTH_LONG).show();
                                } else {


                                    //                ======= instasiasi Kelas detail actifity ====
                                    Intent i = new Intent(MainActivity.this, MainDetail.class);


                            //                    ===== KIRIM DATA KE DETAIL ACTIFITY =====
                                    i.putExtra("namaMhs", namaMhs);
                                    i.putExtra("nimMhs", nimMhs);
                                    i.putExtra("kelasMhs", kelasMhs);

                            //                    JAlLANKAN INTENT
                                    startActivity(i);
                                    finish();


                                }

                            }catch (Exception e){
                                e.printStackTrace();
                                Toast.makeText(MainActivity.this,"ERROR PLEASE TRY AGAIN !!",Toast.LENGTH_SHORT).show();
                            }
            }
        });
    }


}