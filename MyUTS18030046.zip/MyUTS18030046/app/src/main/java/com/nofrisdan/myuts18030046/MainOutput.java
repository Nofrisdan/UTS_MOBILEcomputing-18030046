package com.nofrisdan.myuts18030046;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainOutput extends AppCompatActivity {
    TextView judulProdi,namaMhs,nimMhs,
            kelasMhs,matkulMhs,sksMhs,dosenPengampu,sifatUjian,
            tglUjian,jamUjian;

    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.output_activity);


//        INSTANSIASI ID EDIT TEXT
        judulProdi = (TextView) findViewById(R.id.program_studi);
        namaMhs = (TextView) findViewById(R.id.namaMhs);
        nimMhs = (TextView) findViewById(R.id.nimMhs);
        kelasMhs = (TextView) findViewById(R.id.kelas);
        matkulMhs = (TextView) findViewById(R.id.matkul);
        sksMhs = (TextView) findViewById(R.id.sks);
        dosenPengampu = (TextView) findViewById(R.id.dosenPengampu);
        tglUjian = (TextView) findViewById(R.id.tgl);
        jamUjian = (TextView) findViewById(R.id.waktu);
        sifatUjian = (TextView) findViewById(R.id.sifat_ujian);

        btnBack = (Button) findViewById(R.id.btn_back);



//        Ambil  INtent dari detail
        String nama_mhs = getIntent().getStringExtra("namaMhs");
        String nim_mhs = getIntent().getStringExtra("nimMhs");
        String kelas_mhs = getIntent().getStringExtra("kelasMhs");
        String tgl_ujian = getIntent(). getStringExtra("tgl");
        String jam_ujian = getIntent().getStringExtra("jam");
        String mata_kuliah = getIntent().getStringExtra("matkul");
        String sks = getIntent().getStringExtra("sks");
        String sifat_ujian = getIntent().getStringExtra("sifatUjian");
        String prodi = getIntent().getStringExtra("prodi");
        String dosen_pengampu = getIntent().getStringExtra("dsnPengampu");


//        Tampilkan semuanya di textVIew
        judulProdi.setText("PROGRAM STUDI "+prodi);
        namaMhs.setText(nama_mhs);
        nimMhs.setText(nim_mhs);
        kelasMhs.setText(kelas_mhs);
        matkulMhs.setText(mata_kuliah);
        sksMhs.setText(sks);
        dosenPengampu.setText(dosen_pengampu);
        tglUjian.setText(tgl_ujian);
        jamUjian.setText(jam_ujian);
        sifatUjian.setText(sifat_ujian);


//        JIKA BTN BACK DITEKAN MAKA KEMBALI KE HALAMAN MY ACTIVITY

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Pindahkan ke my actifity
                Intent i = new Intent(MainOutput.this,MainActivity.class);

                startActivity(i);
                finish();
            }
        });




    }

}